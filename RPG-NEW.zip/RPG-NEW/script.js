var hpTotal = 100;
var hpAtual = 0;
var idHpVar = document.getElementById("hpId");

if(hpAtual <= (hpTotal * 98 / 100)){ idHpVar.src = "imagens/98.svg" }
if(hpAtual <= (hpTotal * 96 / 100)){ idHpVar.src = "imagens/96.svg" }
if(hpAtual <= (hpTotal * 94 / 100)){ idHpVar.src = "imagens/94.svg" }
if(hpAtual <= (hpTotal * 92 / 100)){ idHpVar.src = "imagens/92.svg" }
if(hpAtual <= (hpTotal * 90 / 100)){ idHpVar.src = "imagens/90.svg" }
if(hpAtual <= (hpTotal * 88 / 100)){ idHpVar.src = "imagens/88.svg" }
if(hpAtual <= (hpTotal * 86 / 100)){ idHpVar.src = "imagens/86.svg" }
if(hpAtual <= (hpTotal * 84 / 100)){ idHpVar.src = "imagens/84.svg" }
if(hpAtual <= (hpTotal * 82 / 100)){ idHpVar.src = "imagens/82.svg" }
if(hpAtual <= (hpTotal * 80 / 100)){ idHpVar.src = "imagens/80.svg" }
if(hpAtual <= (hpTotal * 78 / 100)){ idHpVar.src = "imagens/78.svg" }
if(hpAtual <= (hpTotal * 76 / 100)){ idHpVar.src = "imagens/76.svg" }
if(hpAtual <= (hpTotal * 74 / 100)){ idHpVar.src = "imagens/74.svg" }
if(hpAtual <= (hpTotal * 72 / 100)){ idHpVar.src = "imagens/72.svg" }
if(hpAtual <= (hpTotal * 70 / 100)){ idHpVar.src = "imagens/70.svg" }
if(hpAtual <= (hpTotal * 68 / 100)){ idHpVar.src = "imagens/68.svg" }
if(hpAtual <= (hpTotal * 66 / 100)){ idHpVar.src = "imagens/66.svg" }
if(hpAtual <= (hpTotal * 64 / 100)){ idHpVar.src = "imagens/64.svg" }
if(hpAtual <= (hpTotal * 62 / 100)){ idHpVar.src = "imagens/62.svg" }
if(hpAtual <= (hpTotal * 60 / 100)){ idHpVar.src = "imagens/60.svg" }
if(hpAtual <= (hpTotal * 58 / 100)){ idHpVar.src = "imagens/58.svg" }
if(hpAtual <= (hpTotal * 56 / 100)){ idHpVar.src = "imagens/56.svg" }
if(hpAtual <= (hpTotal * 54 / 100)){ idHpVar.src = "imagens/54.svg" }
if(hpAtual <= (hpTotal * 52 / 100)){ idHpVar.src = "imagens/52.svg" }
if(hpAtual <= (hpTotal * 50 / 100)){ idHpVar.src = "imagens/50.svg" }
if(hpAtual <= (hpTotal * 48 / 100)){ idHpVar.src = "imagens/48.svg" }
if(hpAtual <= (hpTotal * 46 / 100)){ idHpVar.src = "imagens/46.svg" }
if(hpAtual <= (hpTotal * 44 / 100)){ idHpVar.src = "imagens/44.svg" }
if(hpAtual <= (hpTotal * 42 / 100)){ idHpVar.src = "imagens/42.svg" }
if(hpAtual <= (hpTotal * 40 / 100)){ idHpVar.src = "imagens/40.svg" }
if(hpAtual <= (hpTotal * 38 / 100)){ idHpVar.src = "imagens/38.svg" }
if(hpAtual <= (hpTotal * 36 / 100)){ idHpVar.src = "imagens/36.svg" }
if(hpAtual <= (hpTotal * 34 / 100)){ idHpVar.src = "imagens/34.svg" }
if(hpAtual <= (hpTotal * 32 / 100)){ idHpVar.src = "imagens/32.svg" }
if(hpAtual <= (hpTotal * 30 / 100)){ idHpVar.src = "imagens/30.svg" }
if(hpAtual <= (hpTotal * 28 / 100)){ idHpVar.src = "imagens/28.svg" }
if(hpAtual <= (hpTotal * 26 / 100)){ idHpVar.src = "imagens/26.svg" }
if(hpAtual <= (hpTotal * 24 / 100)){ idHpVar.src = "imagens/24.svg" }
if(hpAtual <= (hpTotal * 22 / 100)){ idHpVar.src = "imagens/22.svg" }
if(hpAtual <= (hpTotal * 20 / 100)){ idHpVar.src = "imagens/20.svg" }
if(hpAtual <= (hpTotal * 18 / 100)){ idHpVar.src = "imagens/18.svg" }
if(hpAtual <= (hpTotal * 16 / 100)){ idHpVar.src = "imagens/16.svg" }
if(hpAtual <= (hpTotal * 14 / 100)){ idHpVar.src = "imagens/14.svg" }
if(hpAtual <= (hpTotal * 12 / 100)){ idHpVar.src = "imagens/12.svg" }
if(hpAtual <= (hpTotal * 10 / 100)){ idHpVar.src = "imagens/10.svg" }
if(hpAtual <= (hpTotal * 8 / 100)){ idHpVar.src = "imagens/8.svg" }
if(hpAtual <= (hpTotal * 6 / 100)){ idHpVar.src = "imagens/6.svg" }
if(hpAtual <= (hpTotal * 4 / 100)){ idHpVar.src = "imagens/4.svg" }
if(hpAtual <= (hpTotal * 2 / 100)){ idHpVar.src = "imagens/2.svg" }
if(hpAtual <= 0){ idHpVar.src = "imagens/0.svg" }
